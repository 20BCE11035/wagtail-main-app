from .base import PageReportView, ReportView  # noqa
