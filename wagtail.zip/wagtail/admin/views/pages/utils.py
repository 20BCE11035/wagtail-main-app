# Retain backwards compatibility for imports
from wagtail.admin.utils import get_valid_next_url_from_request  # noqa
