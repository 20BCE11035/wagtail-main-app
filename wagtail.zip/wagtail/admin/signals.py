from django.dispatch import Signal

# provides args: page, parent
init_new_page = Signal()
