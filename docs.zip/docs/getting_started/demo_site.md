# Demo site

To create a new site on Wagtail, we recommend the `wagtail start` command in [Getting started](index). We also have a demo site, The Wagtail Bakery, which contains example page types and models. We recommend you use the demo site for testing during the development of Wagtail itself.

The source code and installation instructions can be found at <https://github.com/wagtail/bakerydemo>.
