import { ImageChooser } from '../../components/ChooserWidget/ImageChooserWidget';

window.ImageChooser = ImageChooser;
