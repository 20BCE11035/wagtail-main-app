import { ChooserFactory } from '../../components/ChooserWidget';

window.telepath.register('wagtail.admin.widgets.Chooser', ChooserFactory);
