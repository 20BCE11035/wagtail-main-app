/**
 * This method does nothing, returns `undefined`.
 */
// eslint-disable-next-line @typescript-eslint/no-empty-function
const noop = (): void => {};

export { noop };
