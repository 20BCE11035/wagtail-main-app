declare module 'react-shadow';
declare module '*.scss';
